## Setup project

```bash
# cloning this project
git clone https://github.com/romaaji/ROnime.git

# go to the project folder
cd kokunime

# install dependencies
yarn install # or npm install # or pnpm install

# run the project
yarn dev # or npm run dev # or pnpm dev
```

# Setup project

# Setup project

 Ryuzein aji

