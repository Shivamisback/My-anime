const KUSONIME_API = "https://kusonime-scrapper.glitch.me/api";
export default KUSONIME_API;
