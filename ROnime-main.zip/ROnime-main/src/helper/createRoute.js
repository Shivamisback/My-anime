const createRoute = (path, name) => ({ path, name });
export default createRoute;
