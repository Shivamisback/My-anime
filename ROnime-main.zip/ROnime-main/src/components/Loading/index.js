import { memo } from "react";

const Loading = () => (
  <div className="container flex justify-center items-start">
    <div className="lds-roller">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
);

export default memo(Loading);
